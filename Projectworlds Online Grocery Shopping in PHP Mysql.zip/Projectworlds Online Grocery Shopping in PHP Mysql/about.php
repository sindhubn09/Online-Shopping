
<!DOCTYPE html>
<html>
<head>
<title>Projectworlds Grocery Store</title>
<body><?php
require 'dbcon.php';
require 'header.php';
?>
		<div class="w3l_banner_nav_right">
<!-- about -->
		<div class="privacy about">
			<h3>About Us</h3>
India's most convenient online grocery channel Fresh and Smart makes your grocery shopping even simpler. No more hassles of sweating it out in crowded markets, grocery shops & supermarkets - now shop from the comfort of your home; office or on the move.

We offer you convenience of shopping everything that you need for your home - be it fresh vegetables, rice, dals, oil,  household cleaning items & personal care products from a single virtual store.</p>
			<div class="agile_about_grids">
				<div class="col-md-6 agile_about_grid_right">
					<img src="images/31.jpg" alt=" " class="img-responsive" />
				</div>
				<div class="col-md-6 agile_about_grid_left">
					<ol>
						<li>fresh vegetables</li>
						<li>rice, dals, oil</li>
						<li> household cleaning items</li>
						<li>personal care products</li>
					</ol>
				</div>
				<div class="clearfix"> </div>
			</div>
		</div>
<!-- //about -->
		</div>
		<div class="clearfix"></div>
	</div>
<!-- //banner -->
<!-- team -->
	<div class="team">
				<div class="clearfix"> </div>
			</div>
		</div>
	</div>
<!-- //team -->
<!-- testimonials -->
	<div class="testimonials">
		<div class="container">
			
				
		</div>
	</div>
<?php include 'footer.php'?>
</body>
</html>